package com.cmods.inject.scpt;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import com.xvideo.cmods.Charger;
import java.io.InputStream;
import java.io.IOException;

public class Floater extends Service {
	
    @Override
    public void onCreate() {
        super.onCreate();
		Charger.Init(this, this);
    }
    @Override
    public void onDestroy() {
        Charger.Destroy();
        super.onDestroy();
    }
    @Override
    public void onTaskRemoved(Intent paramIntent) {
        stopSelf();
        try {
            Thread.sleep(100L);
        } catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
        }
        super.onTaskRemoved(paramIntent);
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
